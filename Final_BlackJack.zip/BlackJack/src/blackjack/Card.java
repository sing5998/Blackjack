/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package blackjack;

/**
 *
 * @author karan
 */
public class Card {
        private int value;
    private Suit suit;

    public Card(int value, Suit suit) {
        this.value = value;
        this.suit = suit;
    }

    public int getValue() {
        if (value > 10) {
            return 10;
        } else if (value == 1) {
            return 11;
        } else {
            return value;
        }
    }

    public Suit getSuit() {
        return suit;
    }

    public String toString() {
        return valueToString() + " of " + suit.toString();
    }

    private String valueToString() {
        if (value == 1) {
            return "Ace";
        } else if (value == 11) {
            return "Jack";

        } else if (value == 12) {
            return "Queen";
        } else if (value == 13) {
            return "King";
        } else {
            return Integer.toString(value);
        }
    }
}
