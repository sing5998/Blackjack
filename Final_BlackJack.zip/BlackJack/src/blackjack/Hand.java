/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package blackjack;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author karan
 */
public class Hand {
    private List<Card> cards;

public Hand() {
    this.cards = new ArrayList<>();
}

public void addCard(Card card) {
    cards.add(card);
}

public int getHandValue() {
    int value = 0;
    int numAces = 0;

    for (Card card : cards) {
        value += card.getValue();
        if (card.getValue() == 11) {
            numAces++;
        }
    }

    while (value > 21 && numAces > 0) {
        value -= 10;
        numAces--;
    }

    return value;
}

public void printHand() {
    for (Card card : cards) {
        System.out.println(card.toString());
    }
}

public Card getFirstCard() {
    return cards.get(0);
}


}
