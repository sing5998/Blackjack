package blackjack;

import java.util.Scanner;

public class BlackJack {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Deck deck = new Deck();
        deck.shuffle();

        System.out.println("Welcome to Blackjack!");

        Player player = new Player();
        Dealer dealer = new Dealer();

        // Deal initial cards to player and dealer
        player.addCard(deck.drawCard());
        dealer.addCard(deck.drawCard());
        player.addCard(deck.drawCard());
        dealer.addCard(deck.drawCard());

        // Print player's hand
        System.out.println("Your hand: ");
        player.printHand();
        System.out.println("Your total: " + player.getHandValue());

        // Check if player has blackjack
        if (player.getHandValue() == 21) {
            System.out.println("Blackjack! You win!");
            System.exit(0);
        }

        // Print dealer's hand (showing only one card)
        System.out.println("Dealer's hand: ");
        dealer.printHand();

        // Ask player to hit or stand
        while (true) {
            System.out.println("Would you like to hit or stand? (h/s)");
            String choice = input.next();

            if (choice.equals("h")) {
                // Player chooses to hit
                Card card = deck.drawCard();
                System.out.println("You drew a " + card.toString());
                player.addCard(card);
                System.out.println("Your hand: ");
                player.printHand();
                System.out.println("Your total: " + player.getHandValue());
                
                if (player.getHandValue() == 21) {
                    System.out.println("Blackjack! You win!");
                    System.exit(0);
                }
                
                if (player.getHandValue() > 21) {
                    System.out.println("Bust! You lose.");
                    System.exit(0);
                }

            } else if (choice.equals("s")) {
                // Player chooses to stand
                System.out.println("Dealer's hand: ");
                dealer.printHand();

                // Dealer draws cards until hand value is at least 17
                while (dealer.getHandValue() < 17) {
                    Card card = deck.drawCard();
                    dealer.addCard(card);
                    System.out.println("Dealer drew a " + card.toString());
                }

                System.out.println("Dealer's total: " + dealer.getHandValue());

                // Check if dealer busts
                if (dealer.getHandValue() > 21) {
                    System.out.println("Dealer busts! You win!");
                    System.exit(0);
                }

                // Determine the winner
                if (player.getHandValue() > dealer.getHandValue()) {
                    System.out.println("You win!");
                    System.exit(0);
                } else if (player.getHandValue() < dealer.getHandValue()) {
                    System.out.println("You lose.");
                    System.exit(0);
                } else {
                    System.out.println("Push.");
                    System.exit(0);
                }

            } else {
                System.out.println("Invalid choice. Please enter h or s.");
            }
        }
    }
}